using UniversityCourseManagement.Domain.Interfaces;
using UniversityCourseManagement.Infrastructure.Data;
using UniversityCourseManagement.Infrastructure.Repositories;

namespace UniversityCourseManagement.Infrastructure.Factory
{
    /// <summary>
    /// Factory for creating instances of the Course Repository.
    /// This factory implements the Factory pattern for object creation.
    /// </summary>
    public class CourseRepositoryFactory
    {
        /// <summary>
        /// Creates a new instance of the Course Repository.
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <returns>A new instance of the Course Repository.</returns>
        public static ICourseRepository CreateCourseRepository(UniversityCourseManagementDbContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            return new CourseRepository(context);
        }
    }
}

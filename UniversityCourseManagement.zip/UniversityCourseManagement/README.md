# University Course Management System

A comprehensive web application for managing university courses, built with **ASP.NET Core 8.0**, following **Clean Architecture** and **Domain-Driven Design (DDD)** principles.

## Overview

The University Course Management System is a full-stack web application designed to streamline the management of university courses. It provides a complete CRUD (Create, Read, Update, Delete) interface for managing courses, including features like enrollment tracking, course scheduling, and instructor assignment.

## Features

- **Complete CRUD Operations**: Create, read, update, and delete courses
- **Course Management**: Manage course details including name, code, credits, instructor, and semester
- **Enrollment Tracking**: Monitor student enrollment with real-time capacity tracking
- **Responsive UI**: Bootstrap-based responsive design for desktop and mobile devices
- **Data Validation**: Comprehensive input validation using Data Annotations
- **Error Handling**: Robust error handling and user-friendly error messages
- **Logging**: Built-in logging for debugging and monitoring

## Architecture

The project follows **Clean Architecture** principles with clear separation of concerns:

### Layers

1. **Domain Layer** (`Domain/`)
   - Entities: `Course.cs` - Core business entity
   - Interfaces: `ICourseRepository.cs` - Repository contract

2. **Application Layer** (`Application/`)
   - DTOs: `CourseDTO.cs` - Data Transfer Objects
   - ViewModels: `CreateCourseViewModel.cs`, `EditCourseViewModel.cs`
   - Services: `ICourseApplicationService.cs`, `CourseApplicationService.cs` - Business logic

3. **Infrastructure Layer** (`Infrastructure/`)
   - Data: `UniversityCourseManagementDbContext.cs` - Entity Framework Core context
   - Repositories: `CourseRepository.cs` - Data access implementation
   - Factory: `CourseRepositoryFactory.cs` - Object creation pattern

4. **Presentation Layer** (`Presentation.Web/`)
   - Controllers: `CoursesController.cs` - HTTP request handling
   - Views: Razor views for UI (`Index.cshtml`, `Create.cshtml`, `Edit.cshtml`, `Details.cshtml`, `Delete.cshtml`)

## Technology Stack

- **Framework**: ASP.NET Core 8.0
- **Database**: Microsoft SQL Server (via Entity Framework Core)
- **ORM**: Entity Framework Core 8.0
- **Frontend**: Razor Pages, Bootstrap 5, HTML5, CSS3
- **Language**: C# 12
- **Build Tool**: .NET CLI

## Prerequisites

- .NET SDK 8.0 or later
- Microsoft SQL Server (LocalDB or full version)
- Git (for version control)

## Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd UniversityCourseManagement
```

### 2. Restore Dependencies

```bash
dotnet restore
```

### 3. Configure Database Connection

Update the connection string in `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=UniversityCourseManagementDb;Trusted_Connection=true;MultipleActiveResultSets=true;"
  }
}
```

### 4. Apply Migrations

```bash
dotnet ef database update
```

### 5. Build the Project

```bash
dotnet build
```

### 6. Run the Application

```bash
dotnet run
```

The application will be available at `https://localhost:5001` or `http://localhost:5000`.

## Project Structure

```
UniversityCourseManagement/
├── Domain/
│   ├── Entities/
│   │   └── Course.cs
│   └── Interfaces/
│       └── ICourseRepository.cs
├── Application/
│   ├── DTOs/
│   │   └── CourseDTO.cs
│   ├── ViewModels/
│   │   ├── CreateCourseViewModel.cs
│   │   └── EditCourseViewModel.cs
│   └── Services/
│       ├── ICourseApplicationService.cs
│       └── CourseApplicationService.cs
├── Infrastructure/
│   ├── Data/
│   │   └── UniversityCourseManagementDbContext.cs
│   ├── Repositories/
│   │   └── CourseRepository.cs
│   └── Factory/
│       └── CourseRepositoryFactory.cs
├── Presentation.Web/
│   ├── Controllers/
│   │   └── CoursesController.cs
│   └── Views/
│       └── Courses/
│           ├── Index.cshtml
│           ├── Create.cshtml
│           ├── Edit.cshtml
│           ├── Details.cshtml
│           └── Delete.cshtml
├── Pages/
│   ├── Index.cshtml
│   └── Shared/
│       └── _Layout.cshtml
├── Migrations/
│   └── InitialCreate
├── Program.cs
├── appsettings.json
└── README.md
```

## Usage

### Viewing Courses

1. Navigate to the **Courses** section from the navigation menu
2. View all available courses with their enrollment status

### Creating a Course

1. Click **Create New Course** button
2. Fill in the course details:
   - Course Name
   - Course Code
   - Description
   - Credits (1-12)
   - Maximum Students (1-200)
   - Instructor Name
   - Semester
3. Click **Create Course**

### Editing a Course

1. Click the **Edit** button on a course in the list
2. Modify the course details
3. Click **Update Course**

### Viewing Course Details

1. Click the **View** button on a course in the list
2. Review all course information including enrollment status

### Deleting a Course

1. Click the **Delete** button on a course in the list
2. Confirm the deletion on the confirmation page

## Dependency Injection

The application uses ASP.NET Core's built-in Dependency Injection container. Key registrations in `Program.cs`:

```csharp
// Register repositories
builder.Services.AddScoped<ICourseRepository, CourseRepository>();

// Register application services
builder.Services.AddScoped<ICourseApplicationService, CourseApplicationService>();

// Register DbContext
builder.Services.AddDbContext<UniversityCourseManagementDbContext>(options =>
    options.UseSqlServer(connectionString));
```

## Database Migrations

### Create a New Migration

```bash
dotnet ef migrations add MigrationName
```

### Apply Migrations

```bash
dotnet ef database update
```

### Revert Last Migration

```bash
dotnet ef migrations remove
```

## Best Practices Implemented

1. **Separation of Concerns**: Each layer has a specific responsibility
2. **Dependency Inversion**: High-level modules depend on abstractions, not concrete implementations
3. **Single Responsibility Principle**: Each class has a single reason to change
4. **Open/Closed Principle**: Open for extension, closed for modification
5. **Repository Pattern**: Data access is abstracted through repositories
6. **Factory Pattern**: Object creation is centralized in factory classes
7. **Data Annotations**: Input validation at the model level
8. **Async/Await**: Asynchronous operations for better performance
9. **Logging**: Structured logging for debugging and monitoring
10. **Error Handling**: Comprehensive exception handling and user-friendly error messages

## Validation Rules

### Course Entity

- **Name**: Required, 3-200 characters
- **Description**: Required, 10-1000 characters
- **Code**: Required, 2-20 characters, unique
- **Credits**: Required, 1-12
- **MaxStudents**: Required, 1-200
- **CurrentStudents**: 0-200, cannot exceed MaxStudents
- **InstructorName**: Required, 3-200 characters
- **Semester**: Required, 4-10 characters

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Author

Created as a demonstration of Clean Architecture and DDD principles in ASP.NET Core.

## Support

For support, please open an issue in the repository or contact the project maintainer.

## Changelog

### Version 1.0.0 (Initial Release)
- Initial project setup with Clean Architecture
- CRUD operations for courses
- Entity Framework Core integration
- Responsive UI with Bootstrap
- Complete validation and error handling

---

**Built with Clean Architecture and Domain-Driven Design Principles**

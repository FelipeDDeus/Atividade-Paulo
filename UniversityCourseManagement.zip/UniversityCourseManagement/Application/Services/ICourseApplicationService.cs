using UniversityCourseManagement.Application.DTOs;
using UniversityCourseManagement.Application.ViewModels;

namespace UniversityCourseManagement.Application.Services
{
    /// <summary>
    /// Defines the contract for the Course Application Service.
    /// This service handles business logic and orchestrates operations between the domain and infrastructure layers.
    /// </summary>
    public interface ICourseApplicationService
    {
        /// <summary>
        /// Gets all courses asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of course DTOs.</returns>
        Task<IEnumerable<CourseDTO>> GetAllCoursesAsync();

        /// <summary>
        /// Gets a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course DTO if found; otherwise, null.</returns>
        Task<CourseDTO?> GetCourseByIdAsync(int id);

        /// <summary>
        /// Gets courses by semester asynchronously.
        /// </summary>
        /// <param name="semester">The semester to filter by.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of course DTOs for the specified semester.</returns>
        Task<IEnumerable<CourseDTO>> GetCoursesBySemesterAsync(string semester);

        /// <summary>
        /// Creates a new course asynchronously.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the course data to create.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the created course DTO.</returns>
        Task<CourseDTO> CreateCourseAsync(CreateCourseViewModel viewModel);

        /// <summary>
        /// Updates an existing course asynchronously.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the updated course data.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated course DTO.</returns>
        Task<CourseDTO> UpdateCourseAsync(EditCourseViewModel viewModel);

        /// <summary>
        /// Deletes a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task DeleteCourseAsync(int id);

        /// <summary>
        /// Checks if a course exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the course exists; otherwise, false.</returns>
        Task<bool> CourseExistsAsync(int id);
    }
}

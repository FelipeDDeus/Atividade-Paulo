using UniversityCourseManagement.Application.DTOs;
using UniversityCourseManagement.Application.ViewModels;
using UniversityCourseManagement.Domain.Entities;
using UniversityCourseManagement.Domain.Interfaces;

namespace UniversityCourseManagement.Application.Services
{
    /// <summary>
    /// Implementation of the Course Application Service.
    /// Handles business logic and orchestrates operations between the domain and infrastructure layers.
    /// </summary>
    public class CourseApplicationService : ICourseApplicationService
    {
        private readonly ICourseRepository _courseRepository;

        /// <summary>
        /// Initializes a new instance of the CourseApplicationService class.
        /// </summary>
        /// <param name="courseRepository">The course repository for data access.</param>
        public CourseApplicationService(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository ?? throw new ArgumentNullException(nameof(courseRepository));
        }

        /// <summary>
        /// Gets all courses asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of course DTOs.</returns>
        public async Task<IEnumerable<CourseDTO>> GetAllCoursesAsync()
        {
            var courses = await _courseRepository.GetAllAsync();
            return courses.Select(MapToDTO).ToList();
        }

        /// <summary>
        /// Gets a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course DTO if found; otherwise, null.</returns>
        public async Task<CourseDTO?> GetCourseByIdAsync(int id)
        {
            var course = await _courseRepository.GetByIdAsync(id);
            return course != null ? MapToDTO(course) : null;
        }

        /// <summary>
        /// Gets courses by semester asynchronously.
        /// </summary>
        /// <param name="semester">The semester to filter by.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of course DTOs for the specified semester.</returns>
        public async Task<IEnumerable<CourseDTO>> GetCoursesBySemesterAsync(string semester)
        {
            var courses = await _courseRepository.GetBySemesterAsync(semester);
            return courses.Select(MapToDTO).ToList();
        }

        /// <summary>
        /// Creates a new course asynchronously.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the course data to create.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the created course DTO.</returns>
        public async Task<CourseDTO> CreateCourseAsync(CreateCourseViewModel viewModel)
        {
            if (viewModel == null)
                throw new ArgumentNullException(nameof(viewModel));

            var course = new Course
            {
                Name = viewModel.Name,
                Description = viewModel.Description,
                Code = viewModel.Code,
                Credits = viewModel.Credits,
                MaxStudents = viewModel.MaxStudents,
                CurrentStudents = 0,
                InstructorName = viewModel.InstructorName,
                Semester = viewModel.Semester,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var createdCourse = await _courseRepository.AddAsync(course);
            return MapToDTO(createdCourse);
        }

        /// <summary>
        /// Updates an existing course asynchronously.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the updated course data.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated course DTO.</returns>
        public async Task<CourseDTO> UpdateCourseAsync(EditCourseViewModel viewModel)
        {
            if (viewModel == null)
                throw new ArgumentNullException(nameof(viewModel));

            var existingCourse = await _courseRepository.GetByIdAsync(viewModel.Id);
            if (existingCourse == null)
                throw new InvalidOperationException($"Course with ID {viewModel.Id} not found.");

            existingCourse.Name = viewModel.Name;
            existingCourse.Description = viewModel.Description;
            existingCourse.Code = viewModel.Code;
            existingCourse.Credits = viewModel.Credits;
            existingCourse.MaxStudents = viewModel.MaxStudents;
            existingCourse.CurrentStudents = viewModel.CurrentStudents;
            existingCourse.InstructorName = viewModel.InstructorName;
            existingCourse.Semester = viewModel.Semester;
            existingCourse.UpdatedAt = DateTime.UtcNow;

            var updatedCourse = await _courseRepository.UpdateAsync(existingCourse);
            return MapToDTO(updatedCourse);
        }

        /// <summary>
        /// Deletes a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task DeleteCourseAsync(int id)
        {
            var exists = await _courseRepository.ExistsAsync(id);
            if (!exists)
                throw new InvalidOperationException($"Course with ID {id} not found.");

            await _courseRepository.DeleteAsync(id);
        }

        /// <summary>
        /// Checks if a course exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the course exists; otherwise, false.</returns>
        public async Task<bool> CourseExistsAsync(int id)
        {
            return await _courseRepository.ExistsAsync(id);
        }

        /// <summary>
        /// Maps a Course entity to a CourseDTO.
        /// </summary>
        /// <param name="course">The course entity to map.</param>
        /// <returns>The mapped course DTO.</returns>
        private static CourseDTO MapToDTO(Course course)
        {
            return new CourseDTO
            {
                Id = course.Id,
                Name = course.Name,
                Description = course.Description,
                Code = course.Code,
                Credits = course.Credits,
                MaxStudents = course.MaxStudents,
                CurrentStudents = course.CurrentStudents,
                InstructorName = course.InstructorName,
                Semester = course.Semester,
                CreatedAt = course.CreatedAt,
                UpdatedAt = course.UpdatedAt,
                IsFull = course.IsFull,
                AvailableSeats = course.AvailableSeats
            };
        }
    }
}

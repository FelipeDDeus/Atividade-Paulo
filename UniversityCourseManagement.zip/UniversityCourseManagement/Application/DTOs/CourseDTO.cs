namespace UniversityCourseManagement.Application.DTOs
{
    /// <summary>
    /// Data Transfer Object for Course entity.
    /// Used for transferring course data between application layers.
    /// </summary>
    public class CourseDTO
    {
        /// <summary>
        /// Gets or sets the unique identifier for the course.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the course.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the description of the course.
        /// </summary>
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the course code.
        /// </summary>
        public string Code { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the number of credits for the course.
        /// </summary>
        public int Credits { get; set; }

        /// <summary>
        /// Gets or sets the maximum number of students allowed in the course.
        /// </summary>
        public int MaxStudents { get; set; }

        /// <summary>
        /// Gets or sets the current number of students enrolled in the course.
        /// </summary>
        public int CurrentStudents { get; set; }

        /// <summary>
        /// Gets or sets the instructor name for the course.
        /// </summary>
        public string InstructorName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the semester in which the course is offered.
        /// </summary>
        public string Semester { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the date and time when the course was created.
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets the date and time when the course was last updated.
        /// </summary>
        public DateTime UpdatedAt { get; set; }

        /// <summary>
        /// Gets a value indicating whether the course is full.
        /// </summary>
        public bool IsFull { get; set; }

        /// <summary>
        /// Gets the number of available seats in the course.
        /// </summary>
        public int AvailableSeats { get; set; }
    }
}

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace UniversityCourseManagement.Domain.Entities
{
    /// <summary>
    /// Represents a university course entity in the domain layer.
    /// This entity follows DDD principles and contains business logic validation.
    /// </summary>
    [Table("Courses")]
    public class Course
    {
        /// <summary>
        /// Gets or sets the unique identifier for the course.
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the course.
        /// </summary>
        [Required(ErrorMessage = "Course name is required.")]
        [StringLength(200, MinimumLength = 3, ErrorMessage = "Course name must be between 3 and 200 characters.")]
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the description of the course.
        /// </summary>
        [Required(ErrorMessage = "Course description is required.")]
        [StringLength(1000, MinimumLength = 10, ErrorMessage = "Course description must be between 10 and 1000 characters.")]
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the course code (e.g., CS101).
        /// </summary>
        [Required(ErrorMessage = "Course code is required.")]
        [StringLength(20, MinimumLength = 2, ErrorMessage = "Course code must be between 2 and 20 characters.")]
        public string Code { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the number of credits for the course.
        /// </summary>
        [Range(1, 12, ErrorMessage = "Credits must be between 1 and 12.")]
        public int Credits { get; set; }

        /// <summary>
        /// Gets or sets the maximum number of students allowed in the course.
        /// </summary>
        [Range(1, 200, ErrorMessage = "Maximum students must be between 1 and 200.")]
        public int MaxStudents { get; set; }

        /// <summary>
        /// Gets or sets the current number of students enrolled in the course.
        /// </summary>
        [Range(0, 200, ErrorMessage = "Current students cannot be negative or exceed maximum.")]
        public int CurrentStudents { get; set; }

        /// <summary>
        /// Gets or sets the instructor name for the course.
        /// </summary>
        [Required(ErrorMessage = "Instructor name is required.")]
        [StringLength(200, MinimumLength = 3, ErrorMessage = "Instructor name must be between 3 and 200 characters.")]
        public string InstructorName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the semester in which the course is offered (e.g., "2024-1").
        /// </summary>
        [Required(ErrorMessage = "Semester is required.")]
        [StringLength(10, MinimumLength = 4, ErrorMessage = "Semester must be between 4 and 10 characters.")]
        public string Semester { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the date and time when the course was created.
        /// </summary>
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Gets or sets the date and time when the course was last updated.
        /// </summary>
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Gets a value indicating whether the course is full.
        /// </summary>
        [NotMapped]
        public bool IsFull => CurrentStudents >= MaxStudents;

        /// <summary>
        /// Gets the number of available seats in the course.
        /// </summary>
        [NotMapped]
        public int AvailableSeats => MaxStudents - CurrentStudents;
    }
}

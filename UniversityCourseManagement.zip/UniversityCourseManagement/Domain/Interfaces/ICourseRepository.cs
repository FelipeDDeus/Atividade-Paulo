using UniversityCourseManagement.Domain.Entities;

namespace UniversityCourseManagement.Domain.Interfaces
{
    /// <summary>
    /// Defines the contract for the Course repository.
    /// This interface follows the Repository pattern and DDD principles.
    /// </summary>
    public interface ICourseRepository
    {
        /// <summary>
        /// Gets all courses asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of courses.</returns>
        Task<IEnumerable<Course>> GetAllAsync();

        /// <summary>
        /// Gets a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course if found; otherwise, null.</returns>
        Task<Course?> GetByIdAsync(int id);

        /// <summary>
        /// Gets a course by its code asynchronously.
        /// </summary>
        /// <param name="code">The course code.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course if found; otherwise, null.</returns>
        Task<Course?> GetByCodeAsync(string code);

        /// <summary>
        /// Adds a new course asynchronously.
        /// </summary>
        /// <param name="course">The course to add.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the added course.</returns>
        Task<Course> AddAsync(Course course);

        /// <summary>
        /// Updates an existing course asynchronously.
        /// </summary>
        /// <param name="course">The course to update.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated course.</returns>
        Task<Course> UpdateAsync(Course course);

        /// <summary>
        /// Deletes a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task DeleteAsync(int id);

        /// <summary>
        /// Checks if a course exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the course exists; otherwise, false.</returns>
        Task<bool> ExistsAsync(int id);

        /// <summary>
        /// Gets courses by semester asynchronously.
        /// </summary>
        /// <param name="semester">The semester to filter by.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of courses for the specified semester.</returns>
        Task<IEnumerable<Course>> GetBySemesterAsync(string semester);
    }
}

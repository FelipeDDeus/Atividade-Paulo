using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Domain.Entities;

namespace UniversityCourseManagement.Infrastructure.Data
{
    /// <summary>
    /// Entity Framework Core DbContext for the University Course Management application.
    /// This context manages the database connection and entity configurations.
    /// </summary>
    public class UniversityCourseManagementDbContext : DbContext
    {
        /// <summary>
        /// Initializes a new instance of the UniversityCourseManagementDbContext class.
        /// </summary>
        /// <param name="options">The database context options.</param>
        public UniversityCourseManagementDbContext(DbContextOptions<UniversityCourseManagementDbContext> options)
            : base(options)
        {
        }

        /// <summary>
        /// Gets or sets the Courses DbSet.
        /// </summary>
        public DbSet<Course> Courses { get; set; } = null!;
        public DbSet<Instructor> Instructors { get; set; } = null!;

        /// <summary>
        /// Configures the model and entity mappings.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure Instructor entity
            modelBuilder.Entity<Instructor>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasIndex(e => e.Email)
                    .IsUnique();
            });

            // Configure Course entity
            modelBuilder.Entity<Course>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(1000);

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20);



                entity.Property(e => e.Semester)
                    .IsRequired()
                    .HasMaxLength(10);

                // Configure relationship with Instructor (1:N)
                entity.HasOne(c => c.Instructor)
                    .WithMany(i => i.Courses)
                    .HasForeignKey(c => c.InstructorId)
                    .OnDelete(DeleteBehavior.Restrict);

































































































































                entity.Property(e => e.Credits)
                    .IsRequired();

                entity.Property(e => e.MaxStudents)
                    .IsRequired();

                entity.Property(e => e.CurrentStudents)
                    .IsRequired()
                    .HasDefaultValue(0);

                entity.Property(e => e.CreatedAt)
                    .IsRequired()
                    .HasDefaultValueSql("GETUTCDATE()");

                entity.Property(e => e.UpdatedAt)
                    .IsRequired()
                    .HasDefaultValueSql("GETUTCDATE()");

                // Create index on Code for faster lookups
                entity.HasIndex(e => e.Code)
                    .IsUnique();

                // Create index on Semester for filtering
                entity.HasIndex(e => e.Semester);
            });
        }
    }
}

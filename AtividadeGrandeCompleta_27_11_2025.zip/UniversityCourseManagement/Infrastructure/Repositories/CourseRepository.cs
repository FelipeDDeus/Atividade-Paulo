using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Domain.Entities;
using UniversityCourseManagement.Domain.Interfaces;
using UniversityCourseManagement.Infrastructure.Data;

namespace UniversityCourseManagement.Infrastructure.Repositories
{
    /// <summary>
    /// Implementation of the Course Repository.
    /// Handles data access operations for the Course entity using Entity Framework Core.
    /// </summary>
    public class CourseRepository : ICourseRepository
    {
        private readonly UniversityCourseManagementDbContext _context;

        /// <summary>
        /// Initializes a new instance of the CourseRepository class.
        /// </summary>
        /// <param name="context">The database context.</param>
        public CourseRepository(UniversityCourseManagementDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        /// <summary>
        /// Gets all courses asynchronously.
        /// </summary>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of courses.</returns>
        public async Task<IEnumerable<Course>> GetAllAsync(string? includeProperties = null)
        {
            IQueryable<Course> query = _context.Courses.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(',', StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty.Trim());
                }
            }

            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course if found; otherwise, null.</returns>
        public async Task<Course?> GetByIdAsync(int id, string? includeProperties = null)
        {
            IQueryable<Course> query = _context.Courses.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(',', StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty.Trim());
                }
            }

            return await query.FirstOrDefaultAsync(c => c.Id == id);
        }

        /// <summary>
        /// Gets a course by its code asynchronously.
        /// </summary>
        /// <param name="code">The course code.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course if found; otherwise, null.</returns>
        public async Task<Course?> GetByCodeAsync(string code)
        {
            return await _context.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.Code == code);
        }

        /// <summary>
        /// Adds a new course asynchronously.
        /// </summary>
        /// <param name="course">The course to add.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the added course.</returns>
        public async Task<Course> AddAsync(Course course)
        {
            if (course == null)
                throw new ArgumentNullException(nameof(course));

            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return course;
        }

        /// <summary>
        /// Updates an existing course asynchronously.
        /// </summary>
        /// <param name="course">The course to update.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated course.</returns>
        public async Task<Course> UpdateAsync(Course course)
        {
            if (course == null)
                throw new ArgumentNullException(nameof(course));

            _context.Courses.Update(course);
            await _context.SaveChangesAsync();
            return course;
        }

        /// <summary>
        /// Deletes a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task DeleteAsync(int id)
        {
            var course = await _context.Courses.FirstOrDefaultAsync(c => c.Id == id);
            if (course != null)
            {
                _context.Courses.Remove(course);
                await _context.SaveChangesAsync();
            }
        }

        /// <summary>
        /// Checks if a course exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the course exists; otherwise, false.</returns>
        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Courses.AnyAsync(c => c.Id == id);
        }

        /// <summary>
        /// Gets courses by semester asynchronously.
        /// </summary>
        /// <param name="semester">The semester to filter by.</param>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of courses for the specified semester.</returns>
        public async Task<IEnumerable<Course>> GetBySemesterAsync(string semester, string? includeProperties = null)
        {
            IQueryable<Course> query = _context.Courses.AsNoTracking().Where(c => c.Semester == semester);

            if (!string.IsNullOrWhiteSpace(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(',', StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty.Trim());
                }
            }

            return await query.ToListAsync();
        }
    }
}

using Microsoft.EntityFrameworkCore;
using UniversityCourseManagement.Domain.Entities;
using UniversityCourseManagement.Domain.Interfaces;
using UniversityCourseManagement.Infrastructure.Data;

namespace UniversityCourseManagement.Infrastructure.Repositories
{
    /// <summary>
    /// Implementation of the Instructor Repository.
    /// Handles data access operations for the Instructor entity using Entity Framework Core.
    /// </summary>
    public class InstructorRepository : IInstructorRepository
    {
        private readonly UniversityCourseManagementDbContext _context;

        /// <summary>
        /// Initializes a new instance of the InstructorRepository class.
        /// </summary>
        /// <param name="context">The database context.</param>
        public InstructorRepository(UniversityCourseManagementDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        /// <summary>
        /// Gets all instructors asynchronously.
        /// </summary>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of instructors.</returns>
        public async Task<IEnumerable<Instructor>> GetAllAsync(string? includeProperties = null)
        {
            IQueryable<Instructor> query = _context.Instructors.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(',', StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty.Trim());
                }
            }

            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the instructor if found; otherwise, null.</returns>
        public async Task<Instructor?> GetByIdAsync(int id, string? includeProperties = null)
        {
            IQueryable<Instructor> query = _context.Instructors.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(',', StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty.Trim());
                }
            }

            return await query.FirstOrDefaultAsync(i => i.Id == id);
        }

        /// <summary>
        /// Adds a new instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor to add.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the added instructor.</returns>
        public async Task<Instructor> AddAsync(Instructor instructor)
        {
            if (instructor == null)
                throw new ArgumentNullException(nameof(instructor));

            _context.Instructors.Add(instructor);
            await _context.SaveChangesAsync();
            return instructor;
        }

        /// <summary>
        /// Updates an existing instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor to update.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated instructor.</returns>
        public async Task<Instructor> UpdateAsync(Instructor instructor)
        {
            if (instructor == null)
                throw new ArgumentNullException(nameof(instructor));

            _context.Instructors.Update(instructor);
            await _context.SaveChangesAsync();
            return instructor;
        }

        /// <summary>
        /// Deletes an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task DeleteAsync(int id)
        {
            var instructor = await _context.Instructors.FirstOrDefaultAsync(i => i.Id == id);
            if (instructor != null)
            {
                _context.Instructors.Remove(instructor);
                await _context.SaveChangesAsync();
            }
        }

        /// <summary>
        /// Checks if an instructor exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the instructor exists; otherwise, false.</returns>
        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Instructors.AnyAsync(i => i.Id == id);
        }
    }
}

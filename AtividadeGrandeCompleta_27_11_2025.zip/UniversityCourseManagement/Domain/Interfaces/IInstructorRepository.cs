using UniversityCourseManagement.Domain.Entities;

namespace UniversityCourseManagement.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for Instructor entity operations.
    /// Defines the contract for data access operations related to instructors.
    /// </summary>
    public interface IInstructorRepository
    {
        /// <summary>
        /// Gets all instructors asynchronously.
        /// </summary>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of instructors.</returns>
        Task<IEnumerable<Instructor>> GetAllAsync(string? includeProperties = null);

        /// <summary>
        /// Gets an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <param name="includeProperties">Optional comma-separated list of navigation properties to include.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the instructor if found; otherwise, null.</returns>
        Task<Instructor?> GetByIdAsync(int id, string? includeProperties = null);

        /// <summary>
        /// Adds a new instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor entity to add.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the added instructor.</returns>
        Task<Instructor> AddAsync(Instructor instructor);

        /// <summary>
        /// Updates an existing instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor entity to update.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated instructor.</returns>
        Task<Instructor> UpdateAsync(Instructor instructor);

        /// <summary>
        /// Deletes an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task DeleteAsync(int id);

        /// <summary>
        /// Checks if an instructor exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the instructor exists; otherwise, false.</returns>
        Task<bool> ExistsAsync(int id);
    }
}

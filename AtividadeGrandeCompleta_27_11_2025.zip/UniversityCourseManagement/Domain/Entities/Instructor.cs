using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using UniversityCourseManagement.ValidationAttributes;

namespace UniversityCourseManagement.Domain.Entities
{
    public class Instructor
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome do instrutor é obrigatório.")]
        [MaxWords(3, ErrorMessage = "O nome do instrutor não pode ter mais de 3 palavras.")]
        [StringLength(100, ErrorMessage = "O nome não pode exceder 100 caracteres.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "O email do instrutor é obrigatório.")]
        [EmailAddress(ErrorMessage = "Formato de email inválido.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "A data de contratação é obrigatória.")]
        [FutureDate(ErrorMessage = "A data de contratação não pode ser no passado.")]
        public DateTime HireDate { get; set; }

        // Propriedade de navegação para o relacionamento 1:N
        public ICollection<Course> Courses { get; set; } = new List<Course>();
    }
}

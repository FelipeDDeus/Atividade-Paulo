using Microsoft.AspNetCore.Mvc;
using UniversityCourseManagement.Application.Services;
using UniversityCourseManagement.Application.ViewModels;

namespace UniversityCourseManagement.Presentation.Web.Controllers
{
    /// <summary>
    /// Controller for managing courses.
    /// Handles HTTP requests for CRUD operations on courses.
    /// </summary>
    [Route("[controller]")]
    [ApiController]
    public class CoursesController : Controller
    {
        private readonly ICourseApplicationService _courseApplicationService;
        private readonly ILogger<CoursesController> _logger;

        /// <summary>
        /// Initializes a new instance of the CoursesController class.
        /// </summary>
        /// <param name="courseApplicationService">The course application service.</param>
        /// <param name="logger">The logger.</param>
        public CoursesController(ICourseApplicationService courseApplicationService, ILogger<CoursesController> logger)
        {
            _courseApplicationService = courseApplicationService ?? throw new ArgumentNullException(nameof(courseApplicationService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Gets all courses and displays them in a list view.
        /// </summary>
        /// <returns>The view with the list of courses.</returns>
        [HttpGet]
        [Route("")]
        [Route("Index")]
        public async Task<IActionResult> Index()
        {
            try
            {
                var courses = await _courseApplicationService.GetAllCoursesAsync();
                return View(courses);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all courses.");
                TempData["ErrorMessage"] = "An error occurred while retrieving courses.";
                return View(new List<object>());
            }
        }

        /// <summary>
        /// Gets a course by its identifier and displays the details.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>The view with the course details.</returns>
        [HttpGet]
        [Route("Details/{id}")]
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var course = await _courseApplicationService.GetCourseByIdAsync(id);
                if (course == null)
                {
                    TempData["ErrorMessage"] = "Course not found.";
                    return RedirectToAction("Index");
                }

                return View(course);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving course details for ID {CourseId}.", id);
                TempData["ErrorMessage"] = "An error occurred while retrieving course details.";
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Displays the form for creating a new course.
        /// </summary>
        /// <returns>The view with the create course form.</returns>
        [HttpGet]
        [Route("Create")]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Creates a new course.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the course data to create.</param>
        /// <returns>Redirects to the course details page if successful; otherwise, returns the create form.</returns>
        [HttpPost]
        [Route("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateCourseViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            try
            {
                var createdCourse = await _courseApplicationService.CreateCourseAsync(viewModel);
                TempData["SuccessMessage"] = "Course created successfully.";
                return RedirectToAction("Details", new { id = createdCourse.Id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating a new course.");
                ModelState.AddModelError(string.Empty, "An error occurred while creating the course.");
                return View(viewModel);
            }
        }

        /// <summary>
        /// Displays the form for editing an existing course.
        /// </summary>
        /// <param name="id">The unique identifier of the course to edit.</param>
        /// <returns>The view with the edit course form.</returns>
        [HttpGet]
        [Route("Edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var course = await _courseApplicationService.GetCourseByIdAsync(id);
                if (course == null)
                {
                    TempData["ErrorMessage"] = "Course not found.";
                    return RedirectToAction("Index");
                }

                var editViewModel = new EditCourseViewModel
                {
                    Id = course.Id,
                    Name = course.Name,
                    Description = course.Description,
                    Code = course.Code,
                    Credits = course.Credits,
                    MaxStudents = course.MaxStudents,
                    CurrentStudents = course.CurrentStudents,
                    InstructorName = course.InstructorName,
                    Semester = course.Semester
                };

                return View(editViewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving course for edit with ID {CourseId}.", id);
                TempData["ErrorMessage"] = "An error occurred while retrieving the course for editing.";
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Updates an existing course.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the updated course data.</param>
        /// <returns>Redirects to the course details page if successful; otherwise, returns the edit form.</returns>
        [HttpPost]
        [Route("Edit/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, EditCourseViewModel viewModel)
        {
            if (id != viewModel.Id)
            {
                return BadRequest("Course ID mismatch.");
            }

            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            try
            {
                var updatedCourse = await _courseApplicationService.UpdateCourseAsync(viewModel);
                TempData["SuccessMessage"] = "Course updated successfully.";
                return RedirectToAction("Details", new { id = updatedCourse.Id });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Course not found for update with ID {CourseId}.", id);
                TempData["ErrorMessage"] = "Course not found.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating course with ID {CourseId}.", id);
                ModelState.AddModelError(string.Empty, "An error occurred while updating the course.");
                return View(viewModel);
            }
        }

        /// <summary>
        /// Displays the confirmation page for deleting a course.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>The view with the delete confirmation.</returns>
        [HttpGet]
        [Route("Delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var course = await _courseApplicationService.GetCourseByIdAsync(id);
                if (course == null)
                {
                    TempData["ErrorMessage"] = "Course not found.";
                    return RedirectToAction("Index");
                }

                return View(course);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving course for delete with ID {CourseId}.", id);
                TempData["ErrorMessage"] = "An error occurred while retrieving the course for deletion.";
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Deletes a course.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>Redirects to the courses list after successful deletion.</returns>
        [HttpPost]
        [Route("Delete/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await _courseApplicationService.DeleteCourseAsync(id);
                TempData["SuccessMessage"] = "Course deleted successfully.";
                return RedirectToAction("Index");
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Course not found for delete with ID {CourseId}.", id);
                TempData["ErrorMessage"] = "Course not found.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting course with ID {CourseId}.", id);
                TempData["ErrorMessage"] = "An error occurred while deleting the course.";
                return RedirectToAction("Index");
            }
        }
    }
}

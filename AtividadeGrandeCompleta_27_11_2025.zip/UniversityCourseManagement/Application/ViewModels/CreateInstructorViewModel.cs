using System.ComponentModel.DataAnnotations;
using UniversityCourseManagement.ValidationAttributes;

namespace UniversityCourseManagement.Application.ViewModels
{
    /// <summary>
    /// ViewModel for creating a new instructor.
    /// Contains validation rules and display metadata for the create form.
    /// </summary>
    public class CreateInstructorViewModel
    {
        /// <summary>
        /// Gets or sets the name of the instructor.
        /// </summary>
        [Required(ErrorMessage = "O nome do instrutor é obrigatório.")]
        [MaxWords(3, ErrorMessage = "O nome do instrutor não pode ter mais de 3 palavras.")]
        [StringLength(100, ErrorMessage = "O nome não pode exceder 100 caracteres.")]
        [Display(Name = "Nome")]
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the email of the instructor.
        /// </summary>
        [Required(ErrorMessage = "O email do instrutor é obrigatório.")]
        [EmailAddress(ErrorMessage = "Formato de email inválido.")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the hire date of the instructor.
        /// </summary>
        [Required(ErrorMessage = "A data de contratação é obrigatória.")]
        [FutureDate(ErrorMessage = "A data de contratação não pode ser no passado.")]
        [Display(Name = "Data de Contratação")]
        [DataType(DataType.Date)]
        public DateTime HireDate { get; set; }
    }
}

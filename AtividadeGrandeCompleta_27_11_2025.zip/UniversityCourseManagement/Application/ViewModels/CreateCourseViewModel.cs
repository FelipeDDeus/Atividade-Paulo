using System.ComponentModel.DataAnnotations;

namespace UniversityCourseManagement.Application.ViewModels
{
    /// <summary>
    /// ViewModel for creating a new course.
    /// Contains validation rules for user input.
    /// </summary>
    public class CreateCourseViewModel
    {
        /// <summary>
        /// Gets or sets the name of the course.
        /// </summary>
        [Required(ErrorMessage = "Course name is required.")]
        [StringLength(200, MinimumLength = 3, ErrorMessage = "Course name must be between 3 and 200 characters.")]
        [Display(Name = "Course Name")]
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the description of the course.
        /// </summary>
        [Required(ErrorMessage = "Course description is required.")]
        [StringLength(1000, MinimumLength = 10, ErrorMessage = "Course description must be between 10 and 1000 characters.")]
        [Display(Name = "Description")]
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the course code.
        /// </summary>
        [Required(ErrorMessage = "Course code is required.")]
        [StringLength(20, MinimumLength = 2, ErrorMessage = "Course code must be between 2 and 20 characters.")]
        [Display(Name = "Course Code")]
        public string Code { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the number of credits for the course.
        /// </summary>
        [Range(1, 12, ErrorMessage = "Credits must be between 1 and 12.")]
        [Display(Name = "Credits")]
        public int Credits { get; set; }

        /// <summary>
        /// Gets or sets the maximum number of students allowed in the course.
        /// </summary>
        [Range(1, 200, ErrorMessage = "Maximum students must be between 1 and 200.")]
        [Display(Name = "Maximum Students")]
        public int MaxStudents { get; set; }

        /// <summary>
        /// Gets or sets the instructor name for the course.
        /// </summary>
        [Required(ErrorMessage = "O instrutor é obrigatório.")]
        [Display(Name = "Instrutor")]
        public int InstructorId { get; set; }

        /// <summary>
        /// Gets or sets the semester in which the course is offered.
        /// </summary>
        [Required(ErrorMessage = "Semester is required.")]
        [StringLength(10, MinimumLength = 4, ErrorMessage = "Semester must be between 4 and 10 characters.")]
        [Display(Name = "Semester")]
        public string Semester { get; set; } = string.Empty;
    }
}

using UniversityCourseManagement.Domain.Entities;
using UniversityCourseManagement.Domain.Interfaces;
using Mapster;

namespace UniversityCourseManagement.Application.Services
{
    /// <summary>
    /// Implementation of the Instructor Application Service.
    /// Handles business logic and orchestrates operations between the domain and infrastructure layers.
    /// </summary>
    public class InstructorApplicationService : IInstructorApplicationService
    {
        private readonly IInstructorRepository _instructorRepository;

        /// <summary>
        /// Initializes a new instance of the InstructorApplicationService class.
        /// </summary>
        /// <param name="instructorRepository">The instructor repository for data access.</param>
        public InstructorApplicationService(IInstructorRepository instructorRepository)
        {
            _instructorRepository = instructorRepository ?? throw new ArgumentNullException(nameof(instructorRepository));
        }

        /// <summary>
        /// Gets all instructors asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of instructors.</returns>
        public async Task<IEnumerable<Instructor>> GetAllInstructorsAsync()
        {
            var instructors = await _instructorRepository.GetAllAsync(includeProperties: "Courses");
            return instructors;
        }

        /// <summary>
        /// Gets an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the instructor if found; otherwise, null.</returns>
        public async Task<Instructor?> GetInstructorByIdAsync(int id)
        {
            var instructor = await _instructorRepository.GetByIdAsync(id, includeProperties: "Courses");
            return instructor;
        }

        /// <summary>
        /// Adds a new instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor to add.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task AddInstructorAsync(Instructor instructor)
        {
            if (instructor == null)
                throw new ArgumentNullException(nameof(instructor));

            await _instructorRepository.AddAsync(instructor);
        }

        /// <summary>
        /// Updates an existing instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor to update.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task UpdateInstructorAsync(Instructor instructor)
        {
            if (instructor == null)
                throw new ArgumentNullException(nameof(instructor));

            var existingInstructor = await _instructorRepository.GetByIdAsync(instructor.Id);
            if (existingInstructor == null)
                throw new InvalidOperationException($"Instructor with ID {instructor.Id} not found.");

            await _instructorRepository.UpdateAsync(instructor);
        }

        /// <summary>
        /// Deletes an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task DeleteInstructorAsync(int id)
        {
            var exists = await _instructorRepository.ExistsAsync(id);
            if (!exists)
                throw new InvalidOperationException($"Instructor with ID {id} not found.");

            await _instructorRepository.DeleteAsync(id);
        }

        /// <summary>
        /// Checks if an instructor exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the instructor exists; otherwise, false.</returns>
        public async Task<bool> InstructorExistsAsync(int id)
        {
            return await _instructorRepository.ExistsAsync(id);
        }
    }
}

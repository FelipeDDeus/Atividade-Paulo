using UniversityCourseManagement.Application.DTOs;
using UniversityCourseManagement.Application.ViewModels;
using UniversityCourseManagement.Domain.Entities;
using UniversityCourseManagement.Domain.Interfaces;
using Mapster;
using System;

namespace UniversityCourseManagement.Application.Services
{
    /// <summary>
    /// Implementation of the Course Application Service.
    /// Handles business logic and orchestrates operations between the domain and infrastructure layers.
    /// </summary>
    public class CourseApplicationService : ICourseApplicationService
    {
        private readonly ICourseRepository _courseRepository;

        /// <summary>
        /// Initializes a new instance of the CourseApplicationService class.
        /// </summary>
        /// <param name="courseRepository">The course repository for data access.</param>
        public CourseApplicationService(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository ?? throw new ArgumentNullException(nameof(courseRepository));
        }

        /// <summary>
        /// Gets all courses asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of course DTOs.</returns>
        public async Task<IEnumerable<CourseDTO>> GetAllCoursesAsync()
        {
            var courses = await _courseRepository.GetAllAsync(includeProperties: "Instructor");
            return courses.Adapt<IEnumerable<CourseDTO>>().ToList();
        }

        /// <summary>
        /// Gets a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the course DTO if found; otherwise, null.</returns>
        public async Task<CourseDTO?> GetCourseByIdAsync(int id)
        {
            var course = await _courseRepository.GetByIdAsync(id, includeProperties: "Instructor");
            return course?.Adapt<CourseDTO>();
        }

        /// <summary>
        /// Gets courses by semester asynchronously.
        /// </summary>
        /// <param name="semester">The semester to filter by.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of course DTOs for the specified semester.</returns>
        public async Task<IEnumerable<CourseDTO>> GetCoursesBySemesterAsync(string semester)
        {
            var courses = await _courseRepository.GetBySemesterAsync(semester, includeProperties: "Instructor");
            return courses.Adapt<IEnumerable<CourseDTO>>().ToList();
        }

        /// <summary>
        /// Creates a new course asynchronously.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the course data to create.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the created course DTO.</returns>
        public async Task<CourseDTO> CreateCourseAsync(CreateCourseViewModel viewModel)
        {
            if (viewModel == null)
                throw new ArgumentNullException(nameof(viewModel));

            var course = viewModel.Adapt<Course>();
            course.CurrentStudents = 0;
            course.CreatedAt = DateTime.UtcNow;
            course.UpdatedAt = DateTime.UtcNow;

            var createdCourse = await _courseRepository.AddAsync(course);
            return createdCourse.Adapt<CourseDTO>();
        }

        /// <summary>
        /// Updates an existing course asynchronously.
        /// </summary>
        /// <param name="viewModel">The ViewModel containing the updated course data.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated course DTO.</returns>
        public async Task<CourseDTO> UpdateCourseAsync(EditCourseViewModel viewModel)
        {
            if (viewModel == null)
                throw new ArgumentNullException(nameof(viewModel));

            var existingCourse = await _courseRepository.GetByIdAsync(viewModel.Id);
            if (existingCourse == null)
                throw new InvalidOperationException($"Course with ID {viewModel.Id} not found.");

            existingCourse.Name = viewModel.Name;
            existingCourse.Description = viewModel.Description;
            existingCourse.Code = viewModel.Code;
            existingCourse.Credits = viewModel.Credits;
            existingCourse.MaxStudents = viewModel.MaxStudents;
            existingCourse.CurrentStudents = viewModel.CurrentStudents;
            existingCourse.InstructorId = viewModel.InstructorId;
            existingCourse.Semester = viewModel.Semester;
            existingCourse.UpdatedAt = DateTime.UtcNow;

            var updatedCourse = await _courseRepository.UpdateAsync(existingCourse);
            return updatedCourse.Adapt<CourseDTO>();
        }

        /// <summary>
        /// Deletes a course by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task DeleteCourseAsync(int id)
        {
            var exists = await _courseRepository.ExistsAsync(id);
            if (!exists)
                throw new InvalidOperationException($"Course with ID {id} not found.");

            await _courseRepository.DeleteAsync(id);
        }

        /// <summary>
        /// Checks if a course exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the course.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the course exists; otherwise, false.</returns>
        public async Task<bool> CourseExistsAsync(int id)
        {
            return await _courseRepository.ExistsAsync(id);
        }


    }
}

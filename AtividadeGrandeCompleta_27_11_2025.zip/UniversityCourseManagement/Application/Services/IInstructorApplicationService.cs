using UniversityCourseManagement.Domain.Entities;

namespace UniversityCourseManagement.Application.Services
{
    /// <summary>
    /// Interface for the Instructor Application Service.
    /// Defines the contract for business logic operations related to instructors.
    /// </summary>
    public interface IInstructorApplicationService
    {
        /// <summary>
        /// Gets all instructors asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains the collection of instructors.</returns>
        Task<IEnumerable<Instructor>> GetAllInstructorsAsync();

        /// <summary>
        /// Gets an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the instructor if found; otherwise, null.</returns>
        Task<Instructor?> GetInstructorByIdAsync(int id);

        /// <summary>
        /// Adds a new instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor to add.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task AddInstructorAsync(Instructor instructor);

        /// <summary>
        /// Updates an existing instructor asynchronously.
        /// </summary>
        /// <param name="instructor">The instructor to update.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task UpdateInstructorAsync(Instructor instructor);

        /// <summary>
        /// Deletes an instructor by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task DeleteInstructorAsync(int id);

        /// <summary>
        /// Checks if an instructor exists by its identifier asynchronously.
        /// </summary>
        /// <param name="id">The unique identifier of the instructor.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains true if the instructor exists; otherwise, false.</returns>
        Task<bool> InstructorExistsAsync(int id);
    }
}

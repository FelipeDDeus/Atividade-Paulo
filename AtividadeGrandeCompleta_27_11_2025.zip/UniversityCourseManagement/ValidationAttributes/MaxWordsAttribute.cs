using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace UniversityCourseManagement.ValidationAttributes
{
    public class MaxWordsAttribute : ValidationAttribute
    {
        private readonly int _maxWords;

        public MaxWordsAttribute(int maxWords) : base("{0} excede o limite de {1} palavras.")
        {
            _maxWords = maxWords;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null || string.IsNullOrEmpty(value.ToString()))
            {
                return ValidationResult.Success;
            }

            var wordCount = value.ToString().Split(new[] { ' ' }, System.StringSplitOptions.RemoveEmptyEntries).Length;

            if (wordCount > _maxWords)
            {
                var errorMessage = FormatErrorMessage(validationContext.DisplayName);
                return new ValidationResult(errorMessage);
            }

            return ValidationResult.Success;
        }

        public override string FormatErrorMessage(string name)
        {
            return string.Format(ErrorMessageString, name, _maxWords);
        }
    }
}

using System;
using System.ComponentModel.DataAnnotations;

namespace UniversityCourseManagement.ValidationAttributes
{
    public class FutureDateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is DateTime date)
            {
                if (date.Date < DateTime.Today)
                {
                    return new ValidationResult(GetErrorMessage());
                }
            }
            return ValidationResult.Success;
        }

        public string GetErrorMessage() =>
            $"A data deve ser futura ou igual à data de hoje.";
    }
}
